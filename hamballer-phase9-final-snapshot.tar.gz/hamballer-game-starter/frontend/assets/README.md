# Frontend Assets

Place sprites, logos, and other static images for the game in this folder.
